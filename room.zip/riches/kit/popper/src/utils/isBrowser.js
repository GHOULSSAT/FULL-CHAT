export default typeof window !== 'undefined' && typeof document !== 'undefined' && typeof navigator !== 'undefined';
