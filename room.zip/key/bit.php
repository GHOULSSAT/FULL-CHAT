<?php if(!defined('s7V9pz')) {die();}?>
<?php
function cnf($v = "cnf") {
    $cnf["cnf"] = array(
        "mode" => 1,
        "name" => "Grupo - Baevox Framework",
        "tag" => "Something Beyond Limits",
        "poet" => "Baevox",
        "url" => "http://localhost/room/",
        "region" => "Asia/Kolkata",
        "knob" => "knob",
        "door" => "door",
        "gem" => "gem",
        "bit" => "s7V9pz",
        "chief" => "admin",
        "codeword" => "pass",
        "ext" => "css,js,xml",
        "global" => "1",
        "appversion" => 1,
    );
$cnf["Grupo"] = array(
                'host' => 'remotemysql.com',
                'db' => 'v6hyBmcQyC',
                'user' => 'v6hyBmcQyC',
                'pass' => 'S8K4fC0hxX',
                'prefix' => 'gr_'
                );
if ($v == "all") {
        return $cnf;
    } else if (isset($cnf[$v])) {
        return $cnf[$v];
    }
}
?>

