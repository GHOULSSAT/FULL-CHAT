<?php if(!defined('s7V9pz')) {die();}?><?php
load_mine();
?>