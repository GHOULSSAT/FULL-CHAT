<?php if(!defined('s7V9pz')) {die();}?>.notfound.ouch .notfound-404 h1
{
font-family: 'Montserrat', sans-serif;
font-size: 230px;
margin: 0px;
font-weight: 900;
position: absolute;
left: 50%;
-webkit-transform: translateX(-50%);
-ms-transform: translateX(-50%);
transform: translateX(-50%);
background: url('gem/ore/grupo/global/banned.jpg') no-repeat;
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
background-size: cover;
background-position: center;
}

.notfound.ouch a
{
font-family: 'Montserrat', sans-serif;
font-size: 14px;
text-decoration: none;
text-transform: uppercase;
background: #000000;
display: inline-block;
padding: 15px 30px;
border-radius: 40px;
color: #fff;
font-weight: 700;
-webkit-box-shadow: 0px 4px 15px -5px #000000;
box-shadow: 0px 4px 15px -5px #000000;
}